package com.example.veterinariaPatitas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeterinariaPatitasApplicationTests {

	@Test
	void contextLoads() {
	}

}
