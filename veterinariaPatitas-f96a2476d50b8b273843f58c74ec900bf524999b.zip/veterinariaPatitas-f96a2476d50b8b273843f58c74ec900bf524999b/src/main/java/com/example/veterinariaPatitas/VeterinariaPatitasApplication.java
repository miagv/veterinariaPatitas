package com.example.veterinariaPatitas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VeterinariaPatitasApplication {

	public static void main(String[] args) {
		SpringApplication.run(VeterinariaPatitasApplication.class, args);
	}

}
